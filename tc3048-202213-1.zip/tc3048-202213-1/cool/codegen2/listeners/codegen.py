from antlr.coolListener import coolListener
from antlr.coolParser import coolParser
from util.asm import *
from util.dummyasm import *
from util.structure import allClasses

class TextSegment(coolListener):
    def __init__(self):
        self.result = ""
        self.contador = 0

    def enterKlass(self, ctx:coolParser.KlassContext):
        self.currentKlass = ctx.TYPE(0).getText()

    def enterMethod(self, ctx:coolParser.MethodContext):
        self.result += dummyMethodOpen.substitute(Klass=self.currentKlass, method=ctx.ID().getText())

    def exitMethod(self, ctx:coolParser.MethodContext):
        self.result += ctx.expr().code + dummyMethodClose

    def exitStr(self, ctx:coolParser.StrContext):
        # Del segmento de datos se requiere que los [indices est[en generados
        ctx.code = litTpl.substitute(literal="str_const{}".format(10),
                                     value=ctx.getText())

    def exitPri(self, ctx:coolParser.PriContext):
        ctx.code = ctx.primary().code

    def exitCall(self, ctx:coolParser.CallContext):
        #usar callParametersTpl, callStr1, callTpl_instance
        r = ""
        for p in ctx.params:
            r += callParametersTpl.substitute(exp=p.code) # <- push
        r += callStr1a # cargo el self en $a0

        #IO.out_string está en la posición 4, es decir, offset 12
        r += callTpl_instance.substitute(off=12, method=ctx.getText())

        ctx.code = r
    def exitDiv(self, ctx: coolParser.DivContext):
        ctx.code = arithTpl.substitute(left_subexp=ctx.exp(0), right_subexp=ctx.exp(1), op="DIV")
    def exitMul(self, ctx: coolParser.MulContext):
        ctx.code = arithTpl.substitute(left_subexp=ctx.exp(0), right_subexp=ctx.exp(1), op="MUL")
    def exitAdd(self, ctx:coolParser.AddContext):
        ctx.code = arithTpl.substitute(left_subexp=ctx.exp(0), right_subexp=ctx.exp(1), op="ADD")
    def exitNeg(self, ctx: coolParser.NegContext):
        ctx.code = arithTpl.substitute(left_subexp=ctx.exp(0), right_subexp=ctx.exp(1), op="NEG")

    def exitWhile(self, ctx:coolParser.WhileContext):
        etiquetaLoop = "etiqueta"+str(self.contador)
        etiquetaExit = "etiqueta"+str(self.contador+1)
        ctx.code = whileTpl.substitute( label_exit= etiquetaExit, test_subexp=ctx.expr(0),label_loop=etiquetaLoop, loop_subexp=ctx.expr(1))
        self.contador = +str(self.contador) + 2
    def exitIf(self, ctx:coolParser.IfContext):
        etiquetaFalse = "etiqueta"+str(self.contador)
        etiquetaTrue = "etiqueta"+str(self.contador+1)
        ctx.code = ifTpl.substitute(test_subexp=ctx.expr(0), true_subexp=ctx.expr(1), false_subexp=ctx.expr(2), label_false=etiquetaFalse, label_exit=etiquetaTrue)
        self.contador = str(self.contador) +2

class CodeGen():
    def __init__(self, walker, tree):
        self.result = ""
        self.tree = tree
        self.walker = walker
        self.idx = 0

    def generar(self):
        self.segDatos()
        self.segTexto()

    def segDatos(self):
        self.result += dummyasm

    def segTexto(self):
        textSegment = TextSegment()
        self.walker.walk(textSegment, self.tree)

        self.result += textSegment.result


"""
Segmento de Texto:
Código de cada método de acuerdo al dispTab. Debe existir un Main.main
"""
class BadAttributeName(Exception): pass
class BadVariableName(Exception): pass
class BadClassName(Exception): pass
class InvalidInheritance(Exception): pass
class NoMain(Exception): pass
class SelfAssignment(Exception): pass

# Generated from /Users/archanaverma/Desktop/Proyecto/tc3048-202213-1/cool/semantic2/antlr/cool.g4 by ANTLR 4.10.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,47,233,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,1,0,1,0,1,0,5,0,20,8,0,10,0,12,0,23,9,0,1,1,1,1,1,1,1,
        1,3,1,29,8,1,1,1,1,1,1,1,1,1,5,1,35,8,1,10,1,12,1,38,9,1,1,1,1,1,
        1,2,1,2,1,2,1,2,1,2,5,2,47,8,2,10,2,12,2,50,9,2,3,2,52,8,2,1,2,1,
        2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,3,2,66,8,2,3,2,68,8,2,
        1,3,1,3,1,3,1,3,1,4,1,4,1,4,1,4,1,4,1,4,1,4,5,4,81,8,4,10,4,12,4,
        84,9,4,3,4,86,8,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,
        4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,5,4,107,8,4,10,4,12,4,110,9,4,1,4,
        1,4,1,4,1,4,1,4,1,4,1,4,4,4,119,8,4,11,4,12,4,120,1,4,1,4,1,4,1,
        4,1,4,1,4,1,4,1,4,4,4,131,8,4,11,4,12,4,132,1,4,1,4,1,4,1,4,1,4,
        1,4,1,4,1,4,1,4,1,4,1,4,3,4,146,8,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,
        1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,
        1,4,1,4,1,4,1,4,1,4,5,4,176,8,4,10,4,12,4,179,9,4,3,4,181,8,4,1,
        4,1,4,1,4,1,4,3,4,187,8,4,1,4,1,4,1,4,1,4,1,4,1,4,5,4,195,8,4,10,
        4,12,4,198,9,4,3,4,200,8,4,1,4,5,4,203,8,4,10,4,12,4,206,9,4,1,5,
        1,5,1,5,1,5,1,5,1,5,1,5,1,6,1,6,1,6,1,6,1,6,3,6,220,8,6,1,7,1,7,
        1,7,1,7,1,7,1,7,1,7,1,7,1,7,3,7,231,8,7,1,7,0,1,8,8,0,2,4,6,8,10,
        12,14,0,0,267,0,21,1,0,0,0,2,24,1,0,0,0,4,67,1,0,0,0,6,69,1,0,0,
        0,8,145,1,0,0,0,10,207,1,0,0,0,12,214,1,0,0,0,14,230,1,0,0,0,16,
        17,3,2,1,0,17,18,5,1,0,0,18,20,1,0,0,0,19,16,1,0,0,0,20,23,1,0,0,
        0,21,19,1,0,0,0,21,22,1,0,0,0,22,1,1,0,0,0,23,21,1,0,0,0,24,25,5,
        22,0,0,25,28,5,41,0,0,26,27,5,2,0,0,27,29,5,41,0,0,28,26,1,0,0,0,
        28,29,1,0,0,0,29,30,1,0,0,0,30,36,5,3,0,0,31,32,3,4,2,0,32,33,5,
        1,0,0,33,35,1,0,0,0,34,31,1,0,0,0,35,38,1,0,0,0,36,34,1,0,0,0,36,
        37,1,0,0,0,37,39,1,0,0,0,38,36,1,0,0,0,39,40,5,4,0,0,40,3,1,0,0,
        0,41,42,5,42,0,0,42,51,5,5,0,0,43,48,3,6,3,0,44,45,5,6,0,0,45,47,
        3,6,3,0,46,44,1,0,0,0,47,50,1,0,0,0,48,46,1,0,0,0,48,49,1,0,0,0,
        49,52,1,0,0,0,50,48,1,0,0,0,51,43,1,0,0,0,51,52,1,0,0,0,52,53,1,
        0,0,0,53,54,5,7,0,0,54,55,5,8,0,0,55,56,5,41,0,0,56,57,5,3,0,0,57,
        58,3,8,4,0,58,59,5,4,0,0,59,68,1,0,0,0,60,61,5,42,0,0,61,62,5,8,
        0,0,62,65,5,41,0,0,63,64,5,9,0,0,64,66,3,8,4,0,65,63,1,0,0,0,65,
        66,1,0,0,0,66,68,1,0,0,0,67,41,1,0,0,0,67,60,1,0,0,0,68,5,1,0,0,
        0,69,70,5,42,0,0,70,71,5,8,0,0,71,72,5,41,0,0,72,7,1,0,0,0,73,74,
        6,4,-1,0,74,146,3,14,7,0,75,76,5,42,0,0,76,85,5,5,0,0,77,82,3,8,
        4,0,78,79,5,6,0,0,79,81,3,8,4,0,80,78,1,0,0,0,81,84,1,0,0,0,82,80,
        1,0,0,0,82,83,1,0,0,0,83,86,1,0,0,0,84,82,1,0,0,0,85,77,1,0,0,0,
        85,86,1,0,0,0,86,87,1,0,0,0,87,146,5,7,0,0,88,89,5,24,0,0,89,90,
        3,8,4,0,90,91,5,31,0,0,91,92,3,8,4,0,92,93,5,32,0,0,93,94,3,8,4,
        0,94,95,5,23,0,0,95,146,1,0,0,0,96,97,5,33,0,0,97,98,3,8,4,0,98,
        99,5,29,0,0,99,100,3,8,4,0,100,101,5,30,0,0,101,146,1,0,0,0,102,
        103,5,28,0,0,103,108,3,12,6,0,104,105,5,6,0,0,105,107,3,12,6,0,106,
        104,1,0,0,0,107,110,1,0,0,0,108,106,1,0,0,0,108,109,1,0,0,0,109,
        111,1,0,0,0,110,108,1,0,0,0,111,112,5,25,0,0,112,113,3,8,4,16,113,
        146,1,0,0,0,114,115,5,34,0,0,115,116,3,8,4,0,116,118,5,37,0,0,117,
        119,3,10,5,0,118,117,1,0,0,0,119,120,1,0,0,0,120,118,1,0,0,0,120,
        121,1,0,0,0,121,122,1,0,0,0,122,123,5,35,0,0,123,146,1,0,0,0,124,
        125,5,36,0,0,125,146,5,41,0,0,126,130,5,3,0,0,127,128,3,8,4,0,128,
        129,5,1,0,0,129,131,1,0,0,0,130,127,1,0,0,0,131,132,1,0,0,0,132,
        130,1,0,0,0,132,133,1,0,0,0,133,134,1,0,0,0,134,135,5,4,0,0,135,
        146,1,0,0,0,136,137,5,12,0,0,137,146,3,8,4,11,138,139,5,27,0,0,139,
        146,3,8,4,10,140,141,5,20,0,0,141,146,3,8,4,2,142,143,5,42,0,0,143,
        144,5,9,0,0,144,146,3,8,4,1,145,73,1,0,0,0,145,75,1,0,0,0,145,88,
        1,0,0,0,145,96,1,0,0,0,145,102,1,0,0,0,145,114,1,0,0,0,145,124,1,
        0,0,0,145,126,1,0,0,0,145,136,1,0,0,0,145,138,1,0,0,0,145,140,1,
        0,0,0,145,142,1,0,0,0,146,204,1,0,0,0,147,148,10,9,0,0,148,149,5,
        13,0,0,149,203,3,8,4,10,150,151,10,8,0,0,151,152,5,14,0,0,152,203,
        3,8,4,9,153,154,10,7,0,0,154,155,5,15,0,0,155,203,3,8,4,8,156,157,
        10,6,0,0,157,158,5,16,0,0,158,203,3,8,4,7,159,160,10,5,0,0,160,161,
        5,17,0,0,161,203,3,8,4,6,162,163,10,4,0,0,163,164,5,18,0,0,164,203,
        3,8,4,5,165,166,10,3,0,0,166,167,5,19,0,0,167,203,3,8,4,4,168,169,
        10,17,0,0,169,170,5,10,0,0,170,171,5,42,0,0,171,180,5,5,0,0,172,
        177,3,8,4,0,173,174,5,6,0,0,174,176,3,8,4,0,175,173,1,0,0,0,176,
        179,1,0,0,0,177,175,1,0,0,0,177,178,1,0,0,0,178,181,1,0,0,0,179,
        177,1,0,0,0,180,172,1,0,0,0,180,181,1,0,0,0,181,182,1,0,0,0,182,
        203,5,7,0,0,183,186,10,12,0,0,184,185,5,11,0,0,185,187,5,41,0,0,
        186,184,1,0,0,0,186,187,1,0,0,0,187,188,1,0,0,0,188,189,5,10,0,0,
        189,190,5,42,0,0,190,199,5,5,0,0,191,196,3,8,4,0,192,193,5,6,0,0,
        193,195,3,8,4,0,194,192,1,0,0,0,195,198,1,0,0,0,196,194,1,0,0,0,
        196,197,1,0,0,0,197,200,1,0,0,0,198,196,1,0,0,0,199,191,1,0,0,0,
        199,200,1,0,0,0,200,201,1,0,0,0,201,203,5,7,0,0,202,147,1,0,0,0,
        202,150,1,0,0,0,202,153,1,0,0,0,202,156,1,0,0,0,202,159,1,0,0,0,
        202,162,1,0,0,0,202,165,1,0,0,0,202,168,1,0,0,0,202,183,1,0,0,0,
        203,206,1,0,0,0,204,202,1,0,0,0,204,205,1,0,0,0,205,9,1,0,0,0,206,
        204,1,0,0,0,207,208,5,42,0,0,208,209,5,8,0,0,209,210,5,41,0,0,210,
        211,5,21,0,0,211,212,3,8,4,0,212,213,5,1,0,0,213,11,1,0,0,0,214,
        215,5,42,0,0,215,216,5,8,0,0,216,219,5,41,0,0,217,218,5,9,0,0,218,
        220,3,8,4,0,219,217,1,0,0,0,219,220,1,0,0,0,220,13,1,0,0,0,221,222,
        5,5,0,0,222,223,3,8,4,0,223,224,5,7,0,0,224,231,1,0,0,0,225,231,
        5,42,0,0,226,231,5,43,0,0,227,231,5,44,0,0,228,231,5,39,0,0,229,
        231,5,40,0,0,230,221,1,0,0,0,230,225,1,0,0,0,230,226,1,0,0,0,230,
        227,1,0,0,0,230,228,1,0,0,0,230,229,1,0,0,0,231,15,1,0,0,0,22,21,
        28,36,48,51,65,67,82,85,108,120,132,145,177,180,186,196,199,202,
        204,219,230
    ]

class coolParser ( Parser ):

    grammarFileName = "cool.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "';'", "'inherits'", "'{'", "'}'", "'('", 
                     "','", "')'", "':'", "'<-'", "'.'", "'@'", "'\\u02DC'", 
                     "'*'", "'/'", "'+'", "'-'", "'<'", "'<='", "'='", "'not'", 
                     "'=>'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "KLASS", "FI", "IF", "IN", 
                      "INHERITS", "ISVOID", "LET", "LOOP", "POOL", "THEN", 
                      "ELSE", "WHILE", "CASE", "ESAC", "NEW", "OF", "NOT", 
                      "TRUE", "FALSE", "TYPE", "ID", "INTEGER", "STRING", 
                      "COMMENT", "LINE_COMENT", "WS" ]

    RULE_program = 0
    RULE_klass = 1
    RULE_feature = 2
    RULE_formal = 3
    RULE_expr = 4
    RULE_case_stat = 5
    RULE_let_decl = 6
    RULE_primary = 7

    ruleNames =  [ "program", "klass", "feature", "formal", "expr", "case_stat", 
                   "let_decl", "primary" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    KLASS=22
    FI=23
    IF=24
    IN=25
    INHERITS=26
    ISVOID=27
    LET=28
    LOOP=29
    POOL=30
    THEN=31
    ELSE=32
    WHILE=33
    CASE=34
    ESAC=35
    NEW=36
    OF=37
    NOT=38
    TRUE=39
    FALSE=40
    TYPE=41
    ID=42
    INTEGER=43
    STRING=44
    COMMENT=45
    LINE_COMENT=46
    WS=47

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.10.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def klass(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(coolParser.KlassContext)
            else:
                return self.getTypedRuleContext(coolParser.KlassContext,i)


        def getRuleIndex(self):
            return coolParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProgram" ):
                return visitor.visitProgram(self)
            else:
                return visitor.visitChildren(self)




    def program(self):

        localctx = coolParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 21
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==coolParser.KLASS:
                self.state = 16
                self.klass()
                self.state = 17
                self.match(coolParser.T__0)
                self.state = 23
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class KlassContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def KLASS(self):
            return self.getToken(coolParser.KLASS, 0)

        def TYPE(self, i:int=None):
            if i is None:
                return self.getTokens(coolParser.TYPE)
            else:
                return self.getToken(coolParser.TYPE, i)

        def feature(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(coolParser.FeatureContext)
            else:
                return self.getTypedRuleContext(coolParser.FeatureContext,i)


        def getRuleIndex(self):
            return coolParser.RULE_klass

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKlass" ):
                listener.enterKlass(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKlass" ):
                listener.exitKlass(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitKlass" ):
                return visitor.visitKlass(self)
            else:
                return visitor.visitChildren(self)




    def klass(self):

        localctx = coolParser.KlassContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_klass)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 24
            self.match(coolParser.KLASS)
            self.state = 25
            self.match(coolParser.TYPE)
            self.state = 28
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==coolParser.T__1:
                self.state = 26
                self.match(coolParser.T__1)
                self.state = 27
                self.match(coolParser.TYPE)


            self.state = 30
            self.match(coolParser.T__2)
            self.state = 36
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==coolParser.ID:
                self.state = 31
                self.feature()
                self.state = 32
                self.match(coolParser.T__0)
                self.state = 38
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 39
            self.match(coolParser.T__3)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FeatureContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return coolParser.RULE_feature

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class MethodContext(FeatureContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.FeatureContext
            super().__init__(parser)
            self._formal = None # FormalContext
            self.params = list() # of FormalContexts
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(coolParser.ID, 0)
        def TYPE(self):
            return self.getToken(coolParser.TYPE, 0)
        def expr(self):
            return self.getTypedRuleContext(coolParser.ExprContext,0)

        def formal(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(coolParser.FormalContext)
            else:
                return self.getTypedRuleContext(coolParser.FormalContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMethod" ):
                listener.enterMethod(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMethod" ):
                listener.exitMethod(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMethod" ):
                return visitor.visitMethod(self)
            else:
                return visitor.visitChildren(self)


    class AttributeContext(FeatureContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.FeatureContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(coolParser.ID, 0)
        def TYPE(self):
            return self.getToken(coolParser.TYPE, 0)
        def expr(self):
            return self.getTypedRuleContext(coolParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttribute" ):
                listener.enterAttribute(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttribute" ):
                listener.exitAttribute(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAttribute" ):
                return visitor.visitAttribute(self)
            else:
                return visitor.visitChildren(self)



    def feature(self):

        localctx = coolParser.FeatureContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_feature)
        self._la = 0 # Token type
        try:
            self.state = 67
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                localctx = coolParser.MethodContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 41
                self.match(coolParser.ID)
                self.state = 42
                self.match(coolParser.T__4)
                self.state = 51
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==coolParser.ID:
                    self.state = 43
                    localctx._formal = self.formal()
                    localctx.params.append(localctx._formal)
                    self.state = 48
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==coolParser.T__5:
                        self.state = 44
                        self.match(coolParser.T__5)
                        self.state = 45
                        localctx._formal = self.formal()
                        localctx.params.append(localctx._formal)
                        self.state = 50
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)



                self.state = 53
                self.match(coolParser.T__6)
                self.state = 54
                self.match(coolParser.T__7)
                self.state = 55
                self.match(coolParser.TYPE)
                self.state = 56
                self.match(coolParser.T__2)
                self.state = 57
                self.expr(0)
                self.state = 58
                self.match(coolParser.T__3)
                pass

            elif la_ == 2:
                localctx = coolParser.AttributeContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 60
                self.match(coolParser.ID)
                self.state = 61
                self.match(coolParser.T__7)
                self.state = 62
                self.match(coolParser.TYPE)
                self.state = 65
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==coolParser.T__8:
                    self.state = 63
                    self.match(coolParser.T__8)
                    self.state = 64
                    self.expr(0)


                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FormalContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(coolParser.ID, 0)

        def TYPE(self):
            return self.getToken(coolParser.TYPE, 0)

        def getRuleIndex(self):
            return coolParser.RULE_formal

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFormal" ):
                listener.enterFormal(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFormal" ):
                listener.exitFormal(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFormal" ):
                return visitor.visitFormal(self)
            else:
                return visitor.visitChildren(self)




    def formal(self):

        localctx = coolParser.FormalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_formal)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 69
            self.match(coolParser.ID)
            self.state = 70
            self.match(coolParser.T__7)
            self.state = 71
            self.match(coolParser.TYPE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return coolParser.RULE_expr

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class AddContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(coolParser.ExprContext)
            else:
                return self.getTypedRuleContext(coolParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAdd" ):
                listener.enterAdd(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAdd" ):
                listener.exitAdd(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAdd" ):
                return visitor.visitAdd(self)
            else:
                return visitor.visitChildren(self)


    class NewContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NEW(self):
            return self.getToken(coolParser.NEW, 0)
        def TYPE(self):
            return self.getToken(coolParser.TYPE, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNew" ):
                listener.enterNew(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNew" ):
                listener.exitNew(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNew" ):
                return visitor.visitNew(self)
            else:
                return visitor.visitChildren(self)


    class SubContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(coolParser.ExprContext)
            else:
                return self.getTypedRuleContext(coolParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSub" ):
                listener.enterSub(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSub" ):
                listener.exitSub(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSub" ):
                return visitor.visitSub(self)
            else:
                return visitor.visitChildren(self)


    class MulContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(coolParser.ExprContext)
            else:
                return self.getTypedRuleContext(coolParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMul" ):
                listener.enterMul(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMul" ):
                listener.exitMul(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMul" ):
                return visitor.visitMul(self)
            else:
                return visitor.visitChildren(self)


    class PriContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def primary(self):
            return self.getTypedRuleContext(coolParser.PrimaryContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPri" ):
                listener.enterPri(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPri" ):
                listener.exitPri(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPri" ):
                return visitor.visitPri(self)
            else:
                return visitor.visitChildren(self)


    class IsvoidContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ISVOID(self):
            return self.getToken(coolParser.ISVOID, 0)
        def expr(self):
            return self.getTypedRuleContext(coolParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIsvoid" ):
                listener.enterIsvoid(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIsvoid" ):
                listener.exitIsvoid(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIsvoid" ):
                return visitor.visitIsvoid(self)
            else:
                return visitor.visitChildren(self)


    class CallobjContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self._expr = None # ExprContext
            self.params = list() # of ExprContexts
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(coolParser.ExprContext)
            else:
                return self.getTypedRuleContext(coolParser.ExprContext,i)

        def ID(self):
            return self.getToken(coolParser.ID, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCallobj" ):
                listener.enterCallobj(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCallobj" ):
                listener.exitCallobj(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCallobj" ):
                return visitor.visitCallobj(self)
            else:
                return visitor.visitChildren(self)


    class LessContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(coolParser.ExprContext)
            else:
                return self.getTypedRuleContext(coolParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLess" ):
                listener.enterLess(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLess" ):
                listener.exitLess(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLess" ):
                return visitor.visitLess(self)
            else:
                return visitor.visitChildren(self)


    class WhileContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def WHILE(self):
            return self.getToken(coolParser.WHILE, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(coolParser.ExprContext)
            else:
                return self.getTypedRuleContext(coolParser.ExprContext,i)

        def LOOP(self):
            return self.getToken(coolParser.LOOP, 0)
        def POOL(self):
            return self.getToken(coolParser.POOL, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhile" ):
                listener.enterWhile(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhile" ):
                listener.exitWhile(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWhile" ):
                return visitor.visitWhile(self)
            else:
                return visitor.visitChildren(self)


    class EqContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(coolParser.ExprContext)
            else:
                return self.getTypedRuleContext(coolParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEq" ):
                listener.enterEq(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEq" ):
                listener.exitEq(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEq" ):
                return visitor.visitEq(self)
            else:
                return visitor.visitChildren(self)


    class CallContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self._expr = None # ExprContext
            self.params = list() # of ExprContexts
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(coolParser.ID, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(coolParser.ExprContext)
            else:
                return self.getTypedRuleContext(coolParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCall" ):
                listener.enterCall(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCall" ):
                listener.exitCall(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCall" ):
                return visitor.visitCall(self)
            else:
                return visitor.visitChildren(self)


    class DivContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(coolParser.ExprContext)
            else:
                return self.getTypedRuleContext(coolParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDiv" ):
                listener.enterDiv(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDiv" ):
                listener.exitDiv(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDiv" ):
                return visitor.visitDiv(self)
            else:
                return visitor.visitChildren(self)


    class SequenceContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(coolParser.ExprContext)
            else:
                return self.getTypedRuleContext(coolParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSequence" ):
                listener.enterSequence(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSequence" ):
                listener.exitSequence(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSequence" ):
                return visitor.visitSequence(self)
            else:
                return visitor.visitChildren(self)


    class NegContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(coolParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNeg" ):
                listener.enterNeg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNeg" ):
                listener.exitNeg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNeg" ):
                return visitor.visitNeg(self)
            else:
                return visitor.visitChildren(self)


    class NotContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(coolParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNot" ):
                listener.enterNot(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNot" ):
                listener.exitNot(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitNot" ):
                return visitor.visitNot(self)
            else:
                return visitor.visitChildren(self)


    class LesseqContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(coolParser.ExprContext)
            else:
                return self.getTypedRuleContext(coolParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLesseq" ):
                listener.enterLesseq(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLesseq" ):
                listener.exitLesseq(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLesseq" ):
                return visitor.visitLesseq(self)
            else:
                return visitor.visitChildren(self)


    class CallstatContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self._expr = None # ExprContext
            self.params = list() # of ExprContexts
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(coolParser.ExprContext)
            else:
                return self.getTypedRuleContext(coolParser.ExprContext,i)

        def ID(self):
            return self.getToken(coolParser.ID, 0)
        def TYPE(self):
            return self.getToken(coolParser.TYPE, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCallstat" ):
                listener.enterCallstat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCallstat" ):
                listener.exitCallstat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCallstat" ):
                return visitor.visitCallstat(self)
            else:
                return visitor.visitChildren(self)


    class LetContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def LET(self):
            return self.getToken(coolParser.LET, 0)
        def let_decl(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(coolParser.Let_declContext)
            else:
                return self.getTypedRuleContext(coolParser.Let_declContext,i)

        def IN(self):
            return self.getToken(coolParser.IN, 0)
        def expr(self):
            return self.getTypedRuleContext(coolParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLet" ):
                listener.enterLet(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLet" ):
                listener.exitLet(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLet" ):
                return visitor.visitLet(self)
            else:
                return visitor.visitChildren(self)


    class IfContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def IF(self):
            return self.getToken(coolParser.IF, 0)
        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(coolParser.ExprContext)
            else:
                return self.getTypedRuleContext(coolParser.ExprContext,i)

        def THEN(self):
            return self.getToken(coolParser.THEN, 0)
        def ELSE(self):
            return self.getToken(coolParser.ELSE, 0)
        def FI(self):
            return self.getToken(coolParser.FI, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIf" ):
                listener.enterIf(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIf" ):
                listener.exitIf(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIf" ):
                return visitor.visitIf(self)
            else:
                return visitor.visitChildren(self)


    class CaseContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def CASE(self):
            return self.getToken(coolParser.CASE, 0)
        def expr(self):
            return self.getTypedRuleContext(coolParser.ExprContext,0)

        def OF(self):
            return self.getToken(coolParser.OF, 0)
        def ESAC(self):
            return self.getToken(coolParser.ESAC, 0)
        def case_stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(coolParser.Case_statContext)
            else:
                return self.getTypedRuleContext(coolParser.Case_statContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCase" ):
                listener.enterCase(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCase" ):
                listener.exitCase(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCase" ):
                return visitor.visitCase(self)
            else:
                return visitor.visitChildren(self)


    class AssignContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(coolParser.ID, 0)
        def expr(self):
            return self.getTypedRuleContext(coolParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssign" ):
                listener.enterAssign(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssign" ):
                listener.exitAssign(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssign" ):
                return visitor.visitAssign(self)
            else:
                return visitor.visitChildren(self)



    def expr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = coolParser.ExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 8
        self.enterRecursionRule(localctx, 8, self.RULE_expr, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 145
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,12,self._ctx)
            if la_ == 1:
                localctx = coolParser.PriContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 74
                self.primary()
                pass

            elif la_ == 2:
                localctx = coolParser.CallContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 75
                self.match(coolParser.ID)
                self.state = 76
                self.match(coolParser.T__4)
                self.state = 85
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << coolParser.T__2) | (1 << coolParser.T__4) | (1 << coolParser.T__11) | (1 << coolParser.T__19) | (1 << coolParser.IF) | (1 << coolParser.ISVOID) | (1 << coolParser.LET) | (1 << coolParser.WHILE) | (1 << coolParser.CASE) | (1 << coolParser.NEW) | (1 << coolParser.TRUE) | (1 << coolParser.FALSE) | (1 << coolParser.ID) | (1 << coolParser.INTEGER) | (1 << coolParser.STRING))) != 0):
                    self.state = 77
                    localctx._expr = self.expr(0)
                    localctx.params.append(localctx._expr)
                    self.state = 82
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==coolParser.T__5:
                        self.state = 78
                        self.match(coolParser.T__5)
                        self.state = 79
                        localctx._expr = self.expr(0)
                        localctx.params.append(localctx._expr)
                        self.state = 84
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)



                self.state = 87
                self.match(coolParser.T__6)
                pass

            elif la_ == 3:
                localctx = coolParser.IfContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 88
                self.match(coolParser.IF)
                self.state = 89
                self.expr(0)
                self.state = 90
                self.match(coolParser.THEN)
                self.state = 91
                self.expr(0)
                self.state = 92
                self.match(coolParser.ELSE)
                self.state = 93
                self.expr(0)
                self.state = 94
                self.match(coolParser.FI)
                pass

            elif la_ == 4:
                localctx = coolParser.WhileContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 96
                self.match(coolParser.WHILE)
                self.state = 97
                self.expr(0)
                self.state = 98
                self.match(coolParser.LOOP)
                self.state = 99
                self.expr(0)
                self.state = 100
                self.match(coolParser.POOL)
                pass

            elif la_ == 5:
                localctx = coolParser.LetContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 102
                self.match(coolParser.LET)
                self.state = 103
                self.let_decl()
                self.state = 108
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==coolParser.T__5:
                    self.state = 104
                    self.match(coolParser.T__5)
                    self.state = 105
                    self.let_decl()
                    self.state = 110
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 111
                self.match(coolParser.IN)
                self.state = 112
                self.expr(16)
                pass

            elif la_ == 6:
                localctx = coolParser.CaseContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 114
                self.match(coolParser.CASE)
                self.state = 115
                self.expr(0)
                self.state = 116
                self.match(coolParser.OF)
                self.state = 118 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while True:
                    self.state = 117
                    self.case_stat()
                    self.state = 120 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if not (_la==coolParser.ID):
                        break

                self.state = 122
                self.match(coolParser.ESAC)
                pass

            elif la_ == 7:
                localctx = coolParser.NewContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 124
                self.match(coolParser.NEW)
                self.state = 125
                self.match(coolParser.TYPE)
                pass

            elif la_ == 8:
                localctx = coolParser.SequenceContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 126
                self.match(coolParser.T__2)
                self.state = 130 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while True:
                    self.state = 127
                    self.expr(0)
                    self.state = 128
                    self.match(coolParser.T__0)
                    self.state = 132 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << coolParser.T__2) | (1 << coolParser.T__4) | (1 << coolParser.T__11) | (1 << coolParser.T__19) | (1 << coolParser.IF) | (1 << coolParser.ISVOID) | (1 << coolParser.LET) | (1 << coolParser.WHILE) | (1 << coolParser.CASE) | (1 << coolParser.NEW) | (1 << coolParser.TRUE) | (1 << coolParser.FALSE) | (1 << coolParser.ID) | (1 << coolParser.INTEGER) | (1 << coolParser.STRING))) != 0)):
                        break

                self.state = 134
                self.match(coolParser.T__3)
                pass

            elif la_ == 9:
                localctx = coolParser.NegContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 136
                self.match(coolParser.T__11)
                self.state = 137
                self.expr(11)
                pass

            elif la_ == 10:
                localctx = coolParser.IsvoidContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 138
                self.match(coolParser.ISVOID)
                self.state = 139
                self.expr(10)
                pass

            elif la_ == 11:
                localctx = coolParser.NotContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 140
                self.match(coolParser.T__19)
                self.state = 141
                self.expr(2)
                pass

            elif la_ == 12:
                localctx = coolParser.AssignContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 142
                self.match(coolParser.ID)
                self.state = 143
                self.match(coolParser.T__8)
                self.state = 144
                self.expr(1)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 204
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,19,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 202
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,18,self._ctx)
                    if la_ == 1:
                        localctx = coolParser.MulContext(self, coolParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 147
                        if not self.precpred(self._ctx, 9):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 9)")
                        self.state = 148
                        self.match(coolParser.T__12)
                        self.state = 149
                        self.expr(10)
                        pass

                    elif la_ == 2:
                        localctx = coolParser.DivContext(self, coolParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 150
                        if not self.precpred(self._ctx, 8):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 8)")
                        self.state = 151
                        self.match(coolParser.T__13)
                        self.state = 152
                        self.expr(9)
                        pass

                    elif la_ == 3:
                        localctx = coolParser.AddContext(self, coolParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 153
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 154
                        self.match(coolParser.T__14)
                        self.state = 155
                        self.expr(8)
                        pass

                    elif la_ == 4:
                        localctx = coolParser.SubContext(self, coolParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 156
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 157
                        self.match(coolParser.T__15)
                        self.state = 158
                        self.expr(7)
                        pass

                    elif la_ == 5:
                        localctx = coolParser.LessContext(self, coolParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 159
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 160
                        self.match(coolParser.T__16)
                        self.state = 161
                        self.expr(6)
                        pass

                    elif la_ == 6:
                        localctx = coolParser.LesseqContext(self, coolParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 162
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 163
                        self.match(coolParser.T__17)
                        self.state = 164
                        self.expr(5)
                        pass

                    elif la_ == 7:
                        localctx = coolParser.EqContext(self, coolParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 165
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 166
                        self.match(coolParser.T__18)
                        self.state = 167
                        self.expr(4)
                        pass

                    elif la_ == 8:
                        localctx = coolParser.CallobjContext(self, coolParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 168
                        if not self.precpred(self._ctx, 17):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 17)")
                        self.state = 169
                        self.match(coolParser.T__9)
                        self.state = 170
                        self.match(coolParser.ID)
                        self.state = 171
                        self.match(coolParser.T__4)
                        self.state = 180
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        if (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << coolParser.T__2) | (1 << coolParser.T__4) | (1 << coolParser.T__11) | (1 << coolParser.T__19) | (1 << coolParser.IF) | (1 << coolParser.ISVOID) | (1 << coolParser.LET) | (1 << coolParser.WHILE) | (1 << coolParser.CASE) | (1 << coolParser.NEW) | (1 << coolParser.TRUE) | (1 << coolParser.FALSE) | (1 << coolParser.ID) | (1 << coolParser.INTEGER) | (1 << coolParser.STRING))) != 0):
                            self.state = 172
                            localctx._expr = self.expr(0)
                            localctx.params.append(localctx._expr)
                            self.state = 177
                            self._errHandler.sync(self)
                            _la = self._input.LA(1)
                            while _la==coolParser.T__5:
                                self.state = 173
                                self.match(coolParser.T__5)
                                self.state = 174
                                localctx._expr = self.expr(0)
                                localctx.params.append(localctx._expr)
                                self.state = 179
                                self._errHandler.sync(self)
                                _la = self._input.LA(1)



                        self.state = 182
                        self.match(coolParser.T__6)
                        pass

                    elif la_ == 9:
                        localctx = coolParser.CallstatContext(self, coolParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 183
                        if not self.precpred(self._ctx, 12):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 12)")
                        self.state = 186
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        if _la==coolParser.T__10:
                            self.state = 184
                            self.match(coolParser.T__10)
                            self.state = 185
                            self.match(coolParser.TYPE)


                        self.state = 188
                        self.match(coolParser.T__9)
                        self.state = 189
                        self.match(coolParser.ID)
                        self.state = 190
                        self.match(coolParser.T__4)
                        self.state = 199
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)
                        if (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << coolParser.T__2) | (1 << coolParser.T__4) | (1 << coolParser.T__11) | (1 << coolParser.T__19) | (1 << coolParser.IF) | (1 << coolParser.ISVOID) | (1 << coolParser.LET) | (1 << coolParser.WHILE) | (1 << coolParser.CASE) | (1 << coolParser.NEW) | (1 << coolParser.TRUE) | (1 << coolParser.FALSE) | (1 << coolParser.ID) | (1 << coolParser.INTEGER) | (1 << coolParser.STRING))) != 0):
                            self.state = 191
                            localctx._expr = self.expr(0)
                            localctx.params.append(localctx._expr)
                            self.state = 196
                            self._errHandler.sync(self)
                            _la = self._input.LA(1)
                            while _la==coolParser.T__5:
                                self.state = 192
                                self.match(coolParser.T__5)
                                self.state = 193
                                localctx._expr = self.expr(0)
                                localctx.params.append(localctx._expr)
                                self.state = 198
                                self._errHandler.sync(self)
                                _la = self._input.LA(1)



                        self.state = 201
                        self.match(coolParser.T__6)
                        pass

             
                self.state = 206
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,19,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class Case_statContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(coolParser.ID, 0)

        def TYPE(self):
            return self.getToken(coolParser.TYPE, 0)

        def expr(self):
            return self.getTypedRuleContext(coolParser.ExprContext,0)


        def getRuleIndex(self):
            return coolParser.RULE_case_stat

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCase_stat" ):
                listener.enterCase_stat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCase_stat" ):
                listener.exitCase_stat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCase_stat" ):
                return visitor.visitCase_stat(self)
            else:
                return visitor.visitChildren(self)




    def case_stat(self):

        localctx = coolParser.Case_statContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_case_stat)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 207
            self.match(coolParser.ID)
            self.state = 208
            self.match(coolParser.T__7)
            self.state = 209
            self.match(coolParser.TYPE)
            self.state = 210
            self.match(coolParser.T__20)
            self.state = 211
            self.expr(0)
            self.state = 212
            self.match(coolParser.T__0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Let_declContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(coolParser.ID, 0)

        def TYPE(self):
            return self.getToken(coolParser.TYPE, 0)

        def expr(self):
            return self.getTypedRuleContext(coolParser.ExprContext,0)


        def getRuleIndex(self):
            return coolParser.RULE_let_decl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLet_decl" ):
                listener.enterLet_decl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLet_decl" ):
                listener.exitLet_decl(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLet_decl" ):
                return visitor.visitLet_decl(self)
            else:
                return visitor.visitChildren(self)




    def let_decl(self):

        localctx = coolParser.Let_declContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_let_decl)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 214
            self.match(coolParser.ID)
            self.state = 215
            self.match(coolParser.T__7)
            self.state = 216
            self.match(coolParser.TYPE)
            self.state = 219
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==coolParser.T__8:
                self.state = 217
                self.match(coolParser.T__8)
                self.state = 218
                self.expr(0)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrimaryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return coolParser.RULE_primary

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class StrContext(PrimaryContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.PrimaryContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def STRING(self):
            return self.getToken(coolParser.STRING, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStr" ):
                listener.enterStr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStr" ):
                listener.exitStr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStr" ):
                return visitor.visitStr(self)
            else:
                return visitor.visitChildren(self)


    class ParensContext(PrimaryContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.PrimaryContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(coolParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParens" ):
                listener.enterParens(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParens" ):
                listener.exitParens(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParens" ):
                return visitor.visitParens(self)
            else:
                return visitor.visitChildren(self)


    class BoolContext(PrimaryContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.PrimaryContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def TRUE(self):
            return self.getToken(coolParser.TRUE, 0)
        def FALSE(self):
            return self.getToken(coolParser.FALSE, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBool" ):
                listener.enterBool(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBool" ):
                listener.exitBool(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBool" ):
                return visitor.visitBool(self)
            else:
                return visitor.visitChildren(self)


    class VarContext(PrimaryContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.PrimaryContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(coolParser.ID, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVar" ):
                listener.enterVar(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVar" ):
                listener.exitVar(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVar" ):
                return visitor.visitVar(self)
            else:
                return visitor.visitChildren(self)


    class IntContext(PrimaryContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a coolParser.PrimaryContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INTEGER(self):
            return self.getToken(coolParser.INTEGER, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInt" ):
                listener.enterInt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInt" ):
                listener.exitInt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInt" ):
                return visitor.visitInt(self)
            else:
                return visitor.visitChildren(self)



    def primary(self):

        localctx = coolParser.PrimaryContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_primary)
        try:
            self.state = 230
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [coolParser.T__4]:
                localctx = coolParser.ParensContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 221
                self.match(coolParser.T__4)
                self.state = 222
                self.expr(0)
                self.state = 223
                self.match(coolParser.T__6)
                pass
            elif token in [coolParser.ID]:
                localctx = coolParser.VarContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 225
                self.match(coolParser.ID)
                pass
            elif token in [coolParser.INTEGER]:
                localctx = coolParser.IntContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 226
                self.match(coolParser.INTEGER)
                pass
            elif token in [coolParser.STRING]:
                localctx = coolParser.StrContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 227
                self.match(coolParser.STRING)
                pass
            elif token in [coolParser.TRUE]:
                localctx = coolParser.BoolContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 228
                self.match(coolParser.TRUE)
                pass
            elif token in [coolParser.FALSE]:
                localctx = coolParser.BoolContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 229
                self.match(coolParser.FALSE)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[4] = self.expr_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expr_sempred(self, localctx:ExprContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 9)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 8)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 7)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 4:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 6:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 7:
                return self.precpred(self._ctx, 17)
         

            if predIndex == 8:
                return self.precpred(self._ctx, 12)
         





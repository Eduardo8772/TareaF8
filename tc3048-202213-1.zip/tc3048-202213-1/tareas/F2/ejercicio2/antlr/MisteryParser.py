# Generated from /Users/archanaverma/Desktop/Proyecto/tc3048-202213-1/tareas/F2/ejercicio2/antlr/Mistery.g4 by ANTLR 4.10.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,10,19,2,0,7,0,2,1,7,1,1,0,1,0,1,1,5,1,8,8,1,10,1,12,1,11,9,1,
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,2,0,2,0,1,1,0,5,7,17,0,4,1,0,0,0,
        2,9,1,0,0,0,4,5,3,2,1,0,5,1,1,0,0,0,6,8,7,0,0,0,7,6,1,0,0,0,8,11,
        1,0,0,0,9,7,1,0,0,0,9,10,1,0,0,0,10,12,1,0,0,0,11,9,1,0,0,0,12,13,
        5,8,0,0,13,14,5,1,0,0,14,15,5,2,0,0,15,16,5,3,0,0,16,17,5,4,0,0,
        17,3,1,0,0,0,1,9
    ]

class MisteryParser ( Parser ):

    grammarFileName = "Mistery.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'('", "')'", "'{'", "'}'", "'public'", 
                     "'static'", "'void'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "PUBLIC", "STATIC", "VOID", "ID", "INTEGER", 
                      "SPACE" ]

    RULE_prog = 0
    RULE_class = 1

    ruleNames =  [ "prog", "class" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    PUBLIC=5
    STATIC=6
    VOID=7
    ID=8
    INTEGER=9
    SPACE=10

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.10.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def class_(self):
            return self.getTypedRuleContext(MisteryParser.ClassContext,0)


        def getRuleIndex(self):
            return MisteryParser.RULE_prog

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProg" ):
                listener.enterProg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProg" ):
                listener.exitProg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProg" ):
                return visitor.visitProg(self)
            else:
                return visitor.visitChildren(self)




    def prog(self):

        localctx = MisteryParser.ProgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_prog)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 4
            self.class_()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ClassContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(MisteryParser.ID, 0)

        def PUBLIC(self, i:int=None):
            if i is None:
                return self.getTokens(MisteryParser.PUBLIC)
            else:
                return self.getToken(MisteryParser.PUBLIC, i)

        def STATIC(self, i:int=None):
            if i is None:
                return self.getTokens(MisteryParser.STATIC)
            else:
                return self.getToken(MisteryParser.STATIC, i)

        def VOID(self, i:int=None):
            if i is None:
                return self.getTokens(MisteryParser.VOID)
            else:
                return self.getToken(MisteryParser.VOID, i)

        def getRuleIndex(self):
            return MisteryParser.RULE_class

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterClass" ):
                listener.enterClass(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitClass" ):
                listener.exitClass(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitClass" ):
                return visitor.visitClass(self)
            else:
                return visitor.visitChildren(self)




    def class_(self):

        localctx = MisteryParser.ClassContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_class)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 9
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << MisteryParser.PUBLIC) | (1 << MisteryParser.STATIC) | (1 << MisteryParser.VOID))) != 0):
                self.state = 6
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << MisteryParser.PUBLIC) | (1 << MisteryParser.STATIC) | (1 << MisteryParser.VOID))) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 11
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 12
            self.match(MisteryParser.ID)
            self.state = 13
            self.match(MisteryParser.T__0)
            self.state = 14
            self.match(MisteryParser.T__1)
            self.state = 15
            self.match(MisteryParser.T__2)
            self.state = 16
            self.match(MisteryParser.T__3)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx






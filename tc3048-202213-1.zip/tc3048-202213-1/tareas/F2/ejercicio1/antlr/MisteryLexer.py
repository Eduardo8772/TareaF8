# Generated from /Users/archanaverma/Desktop/Proyecto/tc3048-202213-1/tareas/F2/ejercicio1/antlr/Mistery.g4 by ANTLR 4.10.1
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
    from typing import TextIO
else:
    from typing.io import TextIO


def serializedATN():
    return [
        4,0,3,41,6,-1,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,1,0,1,0,1,
        0,1,0,3,0,16,8,0,1,0,1,0,4,0,20,8,0,11,0,12,0,21,1,1,1,1,5,1,26,
        8,1,10,1,12,1,29,9,1,1,2,4,2,32,8,2,11,2,12,2,33,1,3,1,3,3,3,38,
        8,3,1,4,1,4,0,0,5,1,1,3,2,5,3,7,0,9,0,1,0,2,1,0,48,57,4,0,36,36,
        65,90,95,95,97,122,43,0,1,1,0,0,0,0,3,1,0,0,0,0,5,1,0,0,0,1,11,1,
        0,0,0,3,23,1,0,0,0,5,31,1,0,0,0,7,37,1,0,0,0,9,39,1,0,0,0,11,19,
        3,3,1,0,12,15,5,91,0,0,13,16,3,3,1,0,14,16,3,5,2,0,15,13,1,0,0,0,
        15,14,1,0,0,0,16,17,1,0,0,0,17,18,5,93,0,0,18,20,1,0,0,0,19,12,1,
        0,0,0,20,21,1,0,0,0,21,19,1,0,0,0,21,22,1,0,0,0,22,2,1,0,0,0,23,
        27,3,9,4,0,24,26,3,7,3,0,25,24,1,0,0,0,26,29,1,0,0,0,27,25,1,0,0,
        0,27,28,1,0,0,0,28,4,1,0,0,0,29,27,1,0,0,0,30,32,7,0,0,0,31,30,1,
        0,0,0,32,33,1,0,0,0,33,31,1,0,0,0,33,34,1,0,0,0,34,6,1,0,0,0,35,
        38,3,9,4,0,36,38,7,0,0,0,37,35,1,0,0,0,37,36,1,0,0,0,38,8,1,0,0,
        0,39,40,7,1,0,0,40,10,1,0,0,0,6,0,15,21,27,33,37,0
    ]

class MisteryLexer(Lexer):

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    Aa = 1
    ID = 2
    INTEGER = 3

    channelNames = [ u"DEFAULT_TOKEN_CHANNEL", u"HIDDEN" ]

    modeNames = [ "DEFAULT_MODE" ]

    literalNames = [ "<INVALID>",
 ]

    symbolicNames = [ "<INVALID>",
            "Aa", "ID", "INTEGER" ]

    ruleNames = [ "Aa", "ID", "INTEGER", "LetterOrDigit", "Letter" ]

    grammarFileName = "Mistery.g4"

    def __init__(self, input=None, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.10.1")
        self._interp = LexerATNSimulator(self, self.atn, self.decisionsToDFA, PredictionContextCache())
        self._actions = None
        self._predicates = None



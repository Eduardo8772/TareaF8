# Generated from /Users/archanaverma/Desktop/Proyecto/tc3048-202213-1/tareas/F2/ejercicio1/antlr/Mistery.g4 by ANTLR 4.10.1
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .MisteryParser import MisteryParser
else:
    from MisteryParser import MisteryParser

# This class defines a complete listener for a parse tree produced by MisteryParser.
class MisteryListener(ParseTreeListener):

    # Enter a parse tree produced by MisteryParser#prog.
    def enterProg(self, ctx:MisteryParser.ProgContext):
        pass

    # Exit a parse tree produced by MisteryParser#prog.
    def exitProg(self, ctx:MisteryParser.ProgContext):
        pass



del MisteryParser